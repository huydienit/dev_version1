<?php

return [
    'key'   => 'value'
];